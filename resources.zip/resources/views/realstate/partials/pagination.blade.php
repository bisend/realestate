<div class="pagination">
    <div class="center">
        <ul>
          <li><a href="#" class="button small grey"><i class="fa fa-angle-left"></i></a></li>
          <li class="current"><a href="#" class="button small grey">1</a></li>
          <li><a href="#" class="button small grey">2</a></li>
          <li><a href="#" class="button small grey">3</a></li>
          <li><a href="#" class="button small grey"><i class="fa fa-angle-right"></i></a></li>
        </ul>
    </div>
    <div class="clear"></div>
</div>