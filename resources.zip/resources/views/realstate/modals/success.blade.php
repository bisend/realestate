<!-- Button trigger modal -->
<!-- <button data-toggle="modal" data-target="#successModal"></button> -->

<!-- Modal -->
<div class="modal fade successModal" id="successModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-sm">
    <div class="modal-content">
      <div class="modal-body">
         <p><i class="fa fa-check-circle-o" aria-hidden="true"></i>You request is successfully sent!</p>
      </div>
      <div class="modal-footer">
        <button type="button" class="button alt small"  data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>