<div class="bottom-bar">
    <div class="container">
    © 2018  |  Real Estate  |  All Rights Reserved
    </div>
</div>