<?php

return [

    'text_title'                    => 'Dashboard',
    'text_dashboard'                => 'Dashboard',
    'text_visits_today'             => 'Visits Today',
    'text_new_members'              => 'New Members',
    'text_new_listings'             => 'New Listings',
    'text_new_bookings'             => 'New Bookings',
    'text_latest_bookings'          => 'Latest Bookings',
    'text_latest_activity'          => 'Latest Activity',
    'text_view_all'                 => 'View All',
    'text_date'                     => 'Date',
    'text_activity'                 => 'Activity',
    'text_options'                  => 'Options',
    'text_user'                     => 'User',
    'text_listing'                  => 'Listing',

];