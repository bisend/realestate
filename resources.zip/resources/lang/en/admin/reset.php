<?php

return [

    'text_title'            => 'Reset your password',
    'text_reset'            => 'Reset your password',
    'text_email_address'    => 'Email Address',
    'text_login'            => 'Back to login'
];