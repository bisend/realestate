<?php

return [

    'text_title'                => 'Login',
    'text_login'                => 'Login',
    'text_email_address'        => 'Email Address',
    'text_password'             => 'Password',
    'text_forgot'               => 'Forgot your password?',
    'text_remember_me'          => 'Remember me',
    'text_welcome'              => 'Welcome, Admin!',
    'text_please_login'         => 'Please Login',
    'text_copyright'            => 'Copyright &copy; '. date('Y') .', All Rights Reserved - '
];